#!/usr/bin/env python

from setuptools import setup, find_packages

setup(name="phastSim", packages=find_packages())